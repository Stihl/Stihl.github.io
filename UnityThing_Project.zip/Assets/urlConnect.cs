﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class urlConnect : MonoBehaviour
{
    public string url = "https://stihl.github.io/playerShip2_blue%20copy.png";
    public Texture tex;
    // Start is called before the first frame update
    IEnumerator Start()
    {
        using (WWW www = new WWW(url))
        {
            yield return www;
            Renderer renderer = GetComponent<Renderer>();
            tex = www.texture;
            renderer.material.mainTexture = tex;
            
        }
    }
}
