﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class webText : MonoBehaviour
{
    public string webAcText;
    public string url = "https://stihl.github.io/webtext.txt";

    IEnumerator GetTextFromWeb(){
        using (WWW www = new WWW(url))
        {
            yield return www;
            webAcText = www.text;
            this.GetComponent<TextMeshProUGUI>().text = webAcText;
            Debug.Log(webAcText);
            
        }
    }
    void Start()
    {
        StartCoroutine(GetTextFromWeb());
    }
}
