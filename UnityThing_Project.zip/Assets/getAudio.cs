﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class getAudio : MonoBehaviour
{
    public Slider progressBar;
    public string url = "https://stihl.github.io/CoinsPickup%20copy.wav";
    public AudioClip webClip;
    AudioSource aud;
    // Start is called before the first frame update
    IEnumerator GetAudios()
    {
        using (WWW www = new WWW(url))
        {
            while(www.progress != 1){
                Debug.Log(www.progress);
                progressBar.value = www.progress;
                yield return new WaitForEndOfFrame();
            }
            //yield return www;
            //Renderer renderer = GetComponent<Renderer>();
            webClip = www.GetAudioClip();
            aud.clip = webClip;
            aud.Play();
            
            
        }
    }
    void Start(){
        aud = GetComponent<AudioSource>();
        StartCoroutine(GetAudios());
    }
}
